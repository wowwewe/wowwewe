#!/bin/bash
rm -rf CyMySQL
rm -rf cymysql
mv CyMySQL/cymysql ./
rm -rf CyMySQL
